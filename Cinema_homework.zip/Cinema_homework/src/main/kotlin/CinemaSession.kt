import kotlinx.serialization.Serializable
import kotlinx.datetime.LocalDateTime
import kotlin.time.Duration
import kotlinx.datetime.toJavaLocalDateTime
import kotlin.time.toJavaDuration

@Serializable
class CinemaSession(var name: String, var time: LocalDateTime, var duration: Duration) {
    var fixedSeats: MutableList<List<Int>> = mutableListOf()
    var soldSeats: MutableList<List<Int>> = mutableListOf()

    fun changeSessionInfo(newName: String, newTime: LocalDateTime, newDuration: Duration) {
        name = newName
        time = newTime
        duration = newDuration
    }

    fun sessionOverlap(other: CinemaSession) : Boolean {
        return (time.toJavaLocalDateTime() + duration.toJavaDuration() >=
                other.time.toJavaLocalDateTime() &&
                time.toJavaLocalDateTime() + duration.toJavaDuration() <=
                other.time.toJavaLocalDateTime() + other.duration.toJavaDuration()) ||
                (time.toJavaLocalDateTime() >= other.time.toJavaLocalDateTime() &&
                time.toJavaLocalDateTime() <=
                other.time.toJavaLocalDateTime() + other.duration.toJavaDuration())
    }

    fun refund(viewer: Viewer, row: Int, col: Int) {
        for (i in viewer.ticketList) {
            if (i.session == this) {
                viewer.ticketList.remove(i)
                soldSeats.remove(listOf(row, col))
            }
        }
    }

    fun buy(viewer: Viewer, row: Int, col: Int) {
        for (i in soldSeats) {
            if (row == i[0] && col == i[1]){
                println("Данное место уже занято")
                return
            }
            soldSeats.add(listOf(row, col))
            viewer.ticketList.add(Ticket(this, row, col))
        }
    }

    fun getInfo() : String {
        return "${name}\t${time.toJavaLocalDateTime()} - " +
                "${time.toJavaLocalDateTime() + duration.toJavaDuration()}"
    }
}