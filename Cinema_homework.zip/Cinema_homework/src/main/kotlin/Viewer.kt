import kotlinx.serialization.Serializable

@Serializable
class Viewer(val login: String, val hash: Int) {
    var ticketList: MutableList<Ticket> = mutableListOf()
}