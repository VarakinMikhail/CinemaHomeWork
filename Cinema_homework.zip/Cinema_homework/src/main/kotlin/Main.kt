import java.lang.Exception
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

fun getSessionNumber(cinemaRoom: CinemaRoom) : Int {
    for (i in 1..cinemaRoom.sessionList.size) {
        println("$i\t${cinemaRoom.sessionList[i - 1].getInfo()}")
    }
    var num = -1
    try {
        num = readln().toInt()
        if (num < 0 || num > cinemaRoom.sessionList.size) {
            println("Необходимо ввести номер сеанса. Это число не подходит")
            return -1
        }
        return num
    }
    catch (e: Exception) {
        println("Необходимо ввести целое число")
    }
    return num
}

fun main() {
    var authorizationSystem = AuthorizationSystem()
    var cinemaRoom = CinemaRoom(5, 10)

    var result: String = ""
    try {
        FileInputStream("cinema.json").use { fin ->
            var i: Int
            while (fin.read().also { i = it } != -1) {
                result += i.toChar()
            }
        }
        cinemaRoom = Json.decodeFromString<CinemaRoom>(result)
        result = ""
        FileInputStream("authorization.json").use { fin ->
            var i: Int
            while (fin.read().also { i = it } != -1) {
                result += i.toChar()
            }
        }
        authorizationSystem = Json.decodeFromString<AuthorizationSystem>(result)
    } catch (_: Exception) { }

    var code = "99"
    while (code != "0") {
        while(code != "0" && code != "1" && code != "2") {
            print("Если вы зритель, введите 1. Если вы администратор, введите 2. Если хотите выйти, введите 0: ")
            code = readln()
        }

        if (code == "1") {
            var choice = "99"
            while(choice != "0" && choice != "1" && choice != "2") {
                print("Если вы хотите зарегистрироваться, введите 1. " +
                        "Если вы хотите войти, введите 2. Если вы хотите выйти, введите 0: ")
                choice = readln()
            }
            if (choice == "1") {
                authorizationSystem.registerViewer()
            }

            if (choice == "2") {
                viewerUsing(authorizationSystem, cinemaRoom)
            }

            if (choice == "0") {
                code = "99"
            }
        }

        if (code == "2") {
            print("Введите пароль администратора (дан в readme): ")
            val password = readln()
            println()
            if (authorizationSystem.getPasswordHash(password) == 283755526) {
                adminUsing(cinemaRoom)
                code = "99"
            }
        }
    }

    var json = Json.encodeToString(authorizationSystem)

    try {
        FileOutputStream("authorization.json").use { fos ->
            val buffer = json.toByteArray()
            fos.write(buffer, 0, buffer.size)
        }
    } catch (ex: IOException) {
        println(ex.message)
    }

    json = Json.encodeToString(cinemaRoom)

    try {
        FileOutputStream("cinema.json").use { fos ->
            val buffer = json.toByteArray()
            fos.write(buffer, 0, buffer.size)
        }
    } catch (ex: IOException) {
        println(ex.message)
    }
}