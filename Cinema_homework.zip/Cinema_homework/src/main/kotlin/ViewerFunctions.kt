import java.lang.Exception

fun returnTicket(cinemaRoom: CinemaRoom, currentViewer: Viewer) {
    println("Введите номер билета, который хотите вернуть")
    var c = 1
    for (i in currentViewer.ticketList) {
        println("$c " + i.session.getInfo() + ", ${i.row}-й ряд, ${i.col} место")
        c += 1
    }
    var num = -1;
    try {
        num = readln().toInt()
        if (num < 1 || num > currentViewer.ticketList.size) {
            println("Необходимо ввести номер билета. Это число не подходит")
            return
        }
    }
    catch (_: Exception) {
        println("Нужно ввести целое число")
        return
    }
    if (num != -1) {
        currentViewer.ticketList[num - 1].session.soldSeats.remove(listOf(
            currentViewer.ticketList[num - 1].row, currentViewer.ticketList[num - 1].col))
        currentViewer.ticketList.removeAt(num - 1)
        println("Возврат билета осуществлен успешно")
    }
}

fun buyTicket(cinemaRoom: CinemaRoom, currentViewer: Viewer) {
    println("Введите номер сеанса, на который хотите приобрести билет, " +
            "или 0, если хотите выйти")
    val num = getSessionNumber(cinemaRoom)
    if (num != -1 && num != 0) {
        cinemaRoom.showSoldSeats(cinemaRoom.sessionList[num - 1])
        print("Введите номер ряда, на котором хотите приобрести билет: ")
        var row = -1
        while (true){
            try{
                row = readln().toInt()
                break
            }
            catch (e: Exception){
                println("Необходимо ввести целое число")
                print("Введите номер места в этом ряду, на котором хотите приобрести билет: ")
            }
        }
        if (row !in 1..cinemaRoom.rows) {
            println("Данного ряда в кинотеатре нет!")
            return
        }
        print("Введите номер места в этом ряду, на котором хотите приобрести билет: ")
        var col = -1
        while (true) {
            try {
                col = readln().toInt()
                break
            }
            catch (e: Exception) {
                println("Необходимо ввести целое число")
                print("Введите номер места в этом ряду, на котором хотите приобрести билет: ")
            }
        }
        if (col !in 1..cinemaRoom.rows) {
            println("Данного места в кинотеатре нет!")
            return
        }
        val seat = listOf(row, col)
        if (seat in cinemaRoom.sessionList[num - 1].soldSeats) {
            println("Место уже продано")
            return
        }
        else{
            cinemaRoom.sessionList[num - 1].soldSeats.add(seat)
            currentViewer.ticketList.add(Ticket(cinemaRoom.sessionList[num - 1], row, col))
            println("Билет успешно продан!")
        }
    }
}

fun viewerUsing(authorizationSystem: AuthorizationSystem, cinemaRoom: CinemaRoom) {
    val currentViewer = authorizationSystem.authorizeViewer()
    if (currentViewer != null){
        var viewerSigned = true
        while (viewerSigned) {
            println("Если хотите приобрести билет, нажмите 1.\n" +
                    "Если хотите посмотреть список приобретенных билетов, нажмите 2.\n" +
                    "Если хотите вернуть билет, нажмите 3.\n" +
                    "Если хотите выйти, нажмите 0:")
            val viewerChoice = readln()
            if (viewerChoice == "1") {
                buyTicket(cinemaRoom, currentViewer)
            }

            if (viewerChoice == "2") {
                for (i in currentViewer.ticketList) {
                    println(i.session.getInfo() + ", ${i.row}-й ряд, ${i.col} место")
                }
            }

            if (viewerChoice == "3") {
                returnTicket(cinemaRoom, currentViewer)
            }

            if (viewerChoice == "0") {
                viewerSigned = false
            }
        }
    }
}