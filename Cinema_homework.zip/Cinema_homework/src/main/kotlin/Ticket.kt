import kotlinx.serialization.Serializable

@Serializable
class Ticket(val session: CinemaSession, val row: Int, val col: Int) {
}