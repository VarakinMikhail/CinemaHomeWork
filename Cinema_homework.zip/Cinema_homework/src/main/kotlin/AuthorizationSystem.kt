import kotlinx.serialization.Serializable

@Serializable
class AuthorizationSystem() {
    private var listOfViewers: MutableList<Viewer> = mutableListOf()

    private fun getCharHash(i: Char) : Int {
        val polinomHash = (i.code + 1) * (i.code + 1) * (i.code + 2) * (i.code + 4) * (i.code + 5)
                           i.code * (i.code + 1) * (i.code + 2) * (i.code + 4) +
                           i.code * (i.code + 2) * (i.code + 3) +
                           i.code * (i.code + 3) + i.code - 5
        val sinHash = 120 * polinomHash - 20 * polinomHash * polinomHash * polinomHash +
                polinomHash * polinomHash * polinomHash * polinomHash * polinomHash
        return sinHash * polinomHash
    }

    fun getPasswordHash(password: String) : Int {
        var hash = 0
        for (i in password){
            hash += getCharHash(i)
        }
        hash = (hash + 1) * (hash + 1) * (hash + 1) * (hash + 2) * (hash + 3)
        return hash
    }

    private fun validateRegister(login: String, password: String) : Boolean {
        if (password.count() < 5) {
            println("Слишком короткий пароль! Требуется пароль длиной от 5 символов")
            return false
        }
        for (i in listOfViewers) {
            if (i.login == login) {
                println("Этот логин уже используется, попробуйте другой")
                return false
            }
        }
        val hash = getPasswordHash(password)
        listOfViewers.add(Viewer(login, hash))
        return true
    }

    fun registerViewer() {
        var validRegister = false
        while(!validRegister){
            print("Придумайте логин: ")
            val login = readln()
            print("Придумайте пароль: ")
            val password = readln()
            validRegister = validateRegister(login, password)
        }
        println("Добро пожаловать! Авторизуйтесь, и вы сможете приступить к использованию приложения")
    }

    fun authorizeViewer() : Viewer? {
        while(true) {
            print("Введите логин: ")
            val login = readln()
            print("Введите пароль: ")
            val password = readln()
            val hash = getPasswordHash(password)
            for (i in listOfViewers){
                if (i.login == login && i.hash == hash) {
                    println("Вы успешно вошли в аккаунт!")
                    return i
                }
            }
            println("Неверный логин или пароль. Попробуйте снова. Если хотите выйти, введите exit " +
                    "(если хотите ввести пароль снова, нажмите enter): ")
            if(readln() == "exit") {
                return null
            }
        }
    }
}