import kotlinx.datetime.toJavaLocalDateTime
import kotlinx.serialization.Serializable
import kotlin.time.toJavaDuration

@Serializable
class CinemaRoom(val rows: Int, val cols: Int) {
    var sessionList: MutableList<CinemaSession> = mutableListOf()

    private val soldMessages = listOf("Место успешно продано",
        "Это место уже было продано ранее",
        "Такого места в кинозале нет")

    private  val fixedMessages = listOf("Мето успешно зафиксированно",
        "Это место уже было зафиксированно ранее",
        "Такого места в кинозале нет")

    private fun checkPlace(row: Int, col: Int) : Boolean{
        return (row in 0..rows && col in 0..cols)
    }

    fun addSession(session: CinemaSession) {

        for (i in sessionList) {
            if (session.sessionOverlap(i)) {
                println("На это время уже назначен сеанс фильма ${i.name}")
                return
            }
        }
        sessionList.add(session)
        println("Сеанс успешно добавлен")
    }

    private fun markSeat(row: Int, col: Int, seatList: MutableList<List<Int>>) : Int {
        if (row in 0..rows && col in 0..cols && listOf(row, col) !in seatList) {
            seatList.add(listOf(row, col))
            return 0;
        }
        else if (listOf(row, col) in seatList) {
            println("Это место уже было отмечено ранее")
            return 1;
        }
        return 2;
    }

    fun soldSeat(row: Int, col: Int, session: CinemaSession) {
        println(soldMessages[markSeat(row, col, session.soldSeats)])
    }

    fun fixSeat(row: Int, col: Int, session: CinemaSession) {
        println(fixedMessages[markSeat(row, col, session.fixedSeats)])
    }

    private fun showSeats(seatList: MutableList<List<Int>>) {
        print("место")
        for (i in 1..cols) {
            print("\t$i")
        }
        println()
        for (i in 1..rows) {
            print("ряд $i:")
            for (k in 1..cols) {
                print("\t${if (listOf(i, k) in seatList) 1 else 0}")
            }
            println()
        }
    }

    fun showSoldSeats(session: CinemaSession) {
        showSeats(session.soldSeats)
    }

    fun showFixedSeats(session: CinemaSession) {
        showSeats(session.fixedSeats)
    }

    private fun showSeats(name: String, mode: String) {
        for(i in sessionList) {
            if (i.name == name) {
                println("Сеанс с ${i.time} до ${i.time.toJavaLocalDateTime() + i.duration.toJavaDuration()}")
                if (mode == "sold") {
                    showSeats(i.soldSeats)
                }
                else if (mode == "fixed") {
                    showSeats(i.fixedSeats)
                }
                println()
            }
        }
    }

    fun showSoldSeats(name: String) {
        showSeats(name, "sold")
    }

    fun showFixedSeats(name: String) {
        showSeats(name, "fixed")
    }
}