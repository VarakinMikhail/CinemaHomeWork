import kotlinx.datetime.toJavaLocalDateTime
import java.lang.Exception
import java.time.Duration
import kotlin.time.toKotlinDuration

fun printAdminHelp() {
    println("Если хотите добавить сеанс, введите 1.\n" +
            "Если хотите вывести информацию по текущим сеансам, введите 2.\n" +
            "Если хотите вывести информацию по проданным билетам на все сеансы фильма, введите 3.\n" +
            "Если хотите вывести информацию по фактически занятым местам на все " +
            "сеансы фильма, введите 4.\n" +
            "Если хотите добавить место в фактически занятые, введите 5.\n" +
            "Если хотите отредактировать данные сеанса, введите 6.\n" +
            "Если хотите выйти, нажмите 0.")
}

fun addSession(cinemaRoom: CinemaRoom) {
    print("Введите название фильма: ")
    val name = readln()
    var localDateTime1: kotlinx.datetime.LocalDateTime;
    var localDateTime2: kotlinx.datetime.LocalDateTime;

    while (true) {
        print("Введите время начала сеанса в формате 2024-12-31T23:59:59\t")
        val text = readln()
        try {
            localDateTime1 = kotlinx.datetime.LocalDateTime.parse(text)
            break
        } catch (e: Exception) {
            println("Дата введена некорректно! Попробуйте снова")
        }
    }

    while (true) {
        print("Введите время конца сеанса в формате 2024-12-31T23:59:59\t")
        val text = readln()
        try {
            localDateTime2 = kotlinx.datetime.LocalDateTime.parse(text)
            if (localDateTime2 <= localDateTime1){
                println("Введено некорректное время конца сеанса " +
                        "(оно должно быть позже времени начала)")
                continue
            }
            break
        } catch (e: Exception) {
            println("Дата введена некорректно! Попробуйте снова")
        }
    }

    cinemaRoom.addSession(CinemaSession(name, localDateTime1,
        Duration.between(localDateTime1.toJavaLocalDateTime(),
            localDateTime2.toJavaLocalDateTime()).toKotlinDuration()))
}

fun fixSeat(cinemaRoom: CinemaRoom) {
    println("Выберите сеанс:")
    val num = getSessionNumber(cinemaRoom)
    if (num != 0 && num != -1) {
        println("Проданные места:")
        cinemaRoom.showSoldSeats(cinemaRoom.sessionList[num - 1])
        println("Фактически занятые места:")
        cinemaRoom.showFixedSeats(cinemaRoom.sessionList[num - 1])
        print("Введите номер ряда: ")
        var row = -1
        var col = -1
        try {
            row = readln().toInt()
        }
        catch (e: Exception) {
            println("Необходимо ввести целое число")
            return
        }
        print("Введите номер места: ")
        try {
            col = readln().toInt()
        }
        catch (e: Exception) {
            println("Необходимо ввести целое число")
            return
        }
        val seat = listOf(row, col)
        for (i in cinemaRoom.sessionList[num - 1].fixedSeats) {
            if (i == seat) {
                println("Место уже занято")
                return
            }
        }
        for (i in cinemaRoom.sessionList[num - 1].soldSeats) {
            if (i == seat) {
                cinemaRoom.sessionList[num - 1].fixedSeats.add(seat)
                println("Место успешно зафиксированно")
            }
        }
        println("Нельзя занимать еще не проданные места!")
    }
}

fun getStartSessionTime() : kotlinx.datetime.LocalDateTime {
    while (true) {
        print("Введите время начала сеанса в формате 2024-12-31T23:59:59\t")
        val text = readln()
        try {
            return kotlinx.datetime.LocalDateTime.parse(text)
        } catch (e: Exception) {
            println("Дата введена некорректно! Попробуйте снова")
        }
    }
}

fun getFinishSessionTime(startTime: kotlinx.datetime.LocalDateTime) : kotlinx.datetime.LocalDateTime {
    var finishTime: kotlinx.datetime.LocalDateTime
    while (true) {
        print("Введите время конца сеанса в формате 2024-12-31T23:59:59\t")
        val text = readln()
        try {
            finishTime = kotlinx.datetime.LocalDateTime.parse(text)
            if (finishTime <= startTime) {
                println("Введено некорректное время конца сеанса " +
                        "(оно должно быть позже времени начала)")
                continue
            }
            return finishTime
        } catch (e: Exception) {
            println("Дата введена некорректно! Попробуйте снова")
        }
    }
}

fun editSession(cinemaRoom: CinemaRoom) {
    println("Выберите сеанс, который хотите отредактировать, или 0, если хотите выйти: ")
    val num = getSessionNumber(cinemaRoom)
    if (num != -1 && num != 0) {
        println("Введите новые данные:")
        print("Введите название: ")
        val name = readln()
        val startTime = getStartSessionTime()
        val finishTime = getFinishSessionTime(startTime)
        var count = -1;
        for (i in cinemaRoom.sessionList) {
            if (cinemaRoom.sessionList[num-1].sessionOverlap(i)){
                count += 1
            }
        }
        if (count == 0) {
            cinemaRoom.sessionList[num - 1].changeSessionInfo(name, startTime,
                Duration.between(startTime.toJavaLocalDateTime(),
                    finishTime.toJavaLocalDateTime()).toKotlinDuration())
        }
    }
}

fun adminUsing(cinemaRoom: CinemaRoom) {
    var adminSigned = true
    while(adminSigned){
        printAdminHelp()
        val choice = readln()

        when (choice) {
            "0" -> {
                adminSigned = false
            }
            "1" -> {
                addSession(cinemaRoom)
            }
            "2" -> {
                for (i in cinemaRoom.sessionList){
                    println(i.getInfo())
                }
            }
            "3" -> {
                print("Введите название фильма: ")
                val name = readln()
                cinemaRoom.showSoldSeats(name)
            }
            "4" -> {
                print("Введите название фильма: ")
                val name = readln()
                cinemaRoom.showFixedSeats(name)
            }
            "5" -> {
                fixSeat(cinemaRoom)
            }
            "6" -> {
                editSession(cinemaRoom)
            }
        }
    }
}